package testcases;

public class LearnThrow {

	public void divide(int x, int y) {
		if(y!=0) {
			System.out.println(x/y);
		} else {
			throw new ArithmeticException();
		}
	}
	
	public static void main(String[] args) {
		
		LearnThrow lt = new LearnThrow();
		lt.divide(10, 0);
	}
}
