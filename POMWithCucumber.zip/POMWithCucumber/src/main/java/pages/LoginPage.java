package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{

	@Given("Enter username")
	public LoginPage enterUserName() {
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		return this;
	}
	
	@Given("Enter Password")
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	
	@When("Click on Login")
	public HomePage clickLogin() {
		// click on Login button
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}
}
