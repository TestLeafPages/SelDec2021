package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class MyHomePage extends BaseClass{

	public LeadsPage clickLeads() throws InterruptedException {
		Thread.sleep(1000);
		getDriver().findElement(By.linkText(prop1.getProperty("Leads_Link_Text"))).click();
		return new LeadsPage();
	}
}
