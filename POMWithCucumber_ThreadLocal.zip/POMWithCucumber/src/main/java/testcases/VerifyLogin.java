package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class VerifyLogin extends BaseClass{

	@Test//(dataProvider = "fetchData")
	public void runVerifyLogin() {
		LoginPage lp = new LoginPage();
		
		lp.enterUserName("DemoSalesManager")
		.enterPassword("crmsfa")
		.clickLogin()
		.verifyHomePage()
		.clickCRMSFA();
		
	}
}
