package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead extends BaseClass{
	
	@BeforeTest
	public void setUp() {
		fileName = "CreateLead";
	}

	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cName, String fName, String lName) throws InterruptedException {
		
		new HomePage()
		.verifyHomePage()
		.clickCRMSFA()
		.clickLeads()
		.verifyLeadsPage()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLead()
		.verifyFirstName(fName);
	}
}
